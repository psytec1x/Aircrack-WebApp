# Aircrack-ng Web App Entwicklung

## Recherche
- [x] Grundlegende Informationen über Aircrack-ng sammeln
- [x] Hauptfunktionalitäten von Aircrack-ng identifizieren

## Design und Entwicklung
- [x] Web-App-Architektur entwerfen
- [x] Entwicklungsumgebung einrichten
- [x] Kernfunktionalitäten implementieren
- [x] Benutzeroberfläche erstellen
- [x] Funktionalität testen
- [x] Web-Anwendung bereitstellen
- [x] Dokumentation erstellen und dem Benutzer präsentieren
